"use client";

import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { registrationRequestsApi } from "@/lib/api";
import {
  Wrench,
  Users,
  UserPlus,
  Building2,
  Shield,
  Lock,
  LogOut,
  ScrollText,
  BookOpen,
  FileClock,
} from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useLanguage, TranslationKey } from "@/contexts/LanguageContext";

const OTHER_LINKS: {
  href: string;
  labelKey: TranslationKey;
  icon: typeof Users;
  superOnly: boolean;
}[] = [
  {
    href: "/admin/users",
    labelKey: "admLayoutNavUsers",
    icon: Users,
    superOnly: true,
  },
  {
    href: "/admin/registrations",
    labelKey: "admLayoutNavRegistrations",
    icon: UserPlus,
    superOnly: true,
  },
  {
    href: "/admin/homepage-ethics",
    labelKey: "admLayoutNavEthics",
    icon: ScrollText,
    superOnly: true,
  },
  {
    href: "/admin/departments",
    labelKey: "admDeptPageTitle",
    icon: Building2,
    superOnly: true,
  },
  {
    href: "/admin/medleg",
    labelKey: "admMedlegPageTitle",
    icon: BookOpen,
    superOnly: true,
  },
  {
    href: "/admin/log",
    labelKey: "admLayoutNavLog",
    icon: FileClock,
    superOnly: true,
  },
  {
    href: "/admin/admins",
    labelKey: "admAdminsPageTitle",
    icon: Shield,
    superOnly: true,
  },
  {
    href: "/admin/change-password",
    labelKey: "passwordChangeBtn",
    icon: Lock,
    superOnly: false,
  },
];

function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const [pendingCount, setPendingCount] = useState(0);

  const isTools = pathname.startsWith("/admin/tools");

  useEffect(() => {
    // Registrations нь одоо super-only — энгийн admin-д pending badge-ийн
    // хүсэлт хийхгүй (илүүц дуудлагаас сэргийлнэ).
    if (!user?.isSuperAdmin) return;
    let cancelled = false;
    registrationRequestsApi
      .list("pending")
      .then((data: unknown) => {
        if (!cancelled && Array.isArray(data)) setPendingCount(data.length);
      })
      .catch(() => {
        /* ignore — badge is optional */
      });
    return () => {
      cancelled = true;
    };
  }, [user?.isAdmin, pathname]);

  const handleLogout = async () => {
    await logout();
    router.replace("/admin/login");
  };

  const visibleOthers = OTHER_LINKS.filter(
    (l) => !l.superOnly || user?.isSuperAdmin,
  );

  return (
    <aside className="flex flex-col w-48 shrink-0 border-r border-border bg-background min-h-screen sticky top-0">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-border">
        <div className="w-7 h-7 rounded-md bg-muted flex items-center justify-center overflow-hidden ring-1 ring-border/70 shadow-sm">
          <Image
            src="/golomt.jpg"
            alt="Golomt"
            width={20}
            height={20}
            className="rounded object-contain"
          />
        </div>
        <span className="text-sm font-semibold text-foreground tracking-tight">
          Admin
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
        {/* Хэрэгсэл */}
        <Link
          href="/admin/tools"
          className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
            isTools
              ? "bg-muted text-foreground font-semibold ring-hairline shadow-sm"
              : "text-foreground/70 hover:text-foreground hover:bg-muted/50"
          }`}
        >
          <Wrench className="w-3.5 h-3.5 shrink-0" />
          {t("navTools")}
        </Link>

        {/* Бусад */}
        <div className="pt-3 pb-1 px-3">
          <p className="text-[10px] font-semibold text-muted-foreground/50 uppercase tracking-widest">
            {t("admLayoutOtherSectionLabel")}
          </p>
        </div>
        {visibleOthers.map((link) => {
          const Icon = link.icon;
          const active = pathname.startsWith(link.href);
          const showBadge =
            link.href === "/admin/registrations" && pendingCount > 0;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                active
                  ? "bg-muted text-foreground font-semibold ring-hairline shadow-sm"
                  : "text-foreground/70 hover:text-foreground hover:bg-muted/50"
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span className="flex-1 truncate">{t(link.labelKey)}</span>
              {showBadge && (
                <span className="shrink-0 min-w-[1.25rem] h-5 px-1.5 rounded-full bg-amber-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {pendingCount > 99 ? "99+" : pendingCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-2 py-3 border-t border-border space-y-1">
        <div className="flex items-center justify-between px-3 py-1.5">
          <ThemeToggle small />
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-foreground/70 hover:text-red-500 hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-3.5 h-3.5 shrink-0" />
          {t("logout")}
        </button>
      </div>
    </aside>
  );
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  if (pathname === "/admin/login") {
    return <>{children}</>;
  }

  return (
    <div className="admin-shell flex min-h-screen bg-background">
      <AdminSidebar />
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}
