"use client";

import { useMemo, useState, useCallback, useEffect, useRef } from "react";
import { riskApi, getApiErrorMessage, type RiskCurrentRow } from "@/lib/api";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  Loader2,
  AlertTriangle,
  BookmarkPlus,
  Lock,
  LockOpen,
  ClipboardEdit,
  Activity,
  SlidersHorizontal,
  BookOpen,
} from "lucide-react";
import Link from "next/link";
import ToolPageHeader from "@/components/shared/ToolPageHeader";
import { useToast } from "@/hooks/use-toast";
import {
  computeOracleRowScore,
  type ScoreResult,
  type ScoreGroup,
} from "../scoring-rules";
import {
  useIndicatorConfig,
  type DynamicCatalogIndicator,
} from "../use-indicator-config";
import ReportView from "../report-view";
import ReportSkeleton from "../_report-view/report-skeleton";
import MonthFilter, { formatMonthMn } from "../tailan/_MonthFilter";
import IndicatorFilterPanel from "./_IndicatorFilterPanel";

/** YYYY-MM-DD → YYYY-MM */
const monthKeyFromDate = (d: string) => String(d ?? "").slice(0, 7);
import type { ManualMap } from "../indicator-catalog";
import {
  judgementsFromListForBranches,
  oracleSolidsFromRows,
} from "../branch-resolve";

type ScoredRow = RiskCurrentRow & {
  __score: ScoreResult;
  __scoreLabel: string | null;
  __group: ScoreGroup | null;
};

function toScored(
  rows: RiskCurrentRow[],
  catalog: DynamicCatalogIndicator[],
): ScoredRow[] {
  return rows
    .filter((r) => r.rowType === "oracle")
    .map((r) => {
      const subid = String(r.SUBID ?? "").trim();
      const {
        score,
        label,
        indicator: ind,
      } = computeOracleRowScore(catalog, subid, r.RESULT, r.RESULT_TYPE);
      const grpNum = ind?.group;
      const __group: ScoreGroup | null =
        grpNum === 1
          ? "Score 1"
          : grpNum === 2
            ? "Score 2"
            : grpNum === 3
              ? "Score 3"
              : null;
      return {
        ...r,
        __score: score as ScoreResult,
        __scoreLabel: label,
        __group,
      };
    });
}

type SaveModalMeta = {
  pDate: string;
};

interface MonitorContentProps {
  saveModalOpenHandler: (meta: SaveModalMeta) => void;
}

function MonitorContent({ saveModalOpenHandler }: MonitorContentProps) {
  const { t } = useLanguage();
  const { toast } = useToast();

  const showSaveError = useCallback(
    (e: unknown) => {
      toast({
        variant: "destructive",
        title: t("riskSaveError"),
        description: getApiErrorMessage(e),
      });
    },
    [t, toast],
  );

  const [rows, setRows] = useState<RiskCurrentRow[]>([]);
  const [fetchedDate, setFetchedDate] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  // [UI] Дата сард нэг удаа ордог тул өдрөөр биш САРААР сонгоно (tailan шиг).
  const [selectedMonth, setSelectedMonth] = useState("");
  const [riskbranchDates, setRiskbranchDates] = useState<string[]>([]);
  const riskbranchDatesRef = useRef<string[]>([]);
  riskbranchDatesRef.current = riskbranchDates;
  const [lockedDate, setLockedDate] = useState<string | null>(null);
  const [judgements, setJudgements] = useState<Record<string, number>>({});
  const [judgementComments, setJudgementComments] = useState<
    Record<string, string>
  >({});
  const [prevJudgements, setPrevJudgements] = useState<Record<string, number>>(
    {},
  );

  const [loading, setLoading] = useState(true);
  const [loadingDate, setLoadingDate] = useState(false);
  const [lockingDate, setLockingDate] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [riskFilter, setRiskFilter] = useState<
    "all" | "Өндөр" | "Дунд" | "Бага"
  >("all");

  const judgementTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>(
    {},
  );
  const judgementCommentsRef = useRef(judgementComments);
  judgementCommentsRef.current = judgementComments;
  const manualTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>(
    {},
  );
  const loadAbortRef = useRef<AbortController | null>(null);

  const [manualMap, setManualMap] = useState<ManualMap>({});
  const [filterOpen, setFilterOpen] = useState(false);
  const [filterIndId, setFilterIndId] = useState("");

  const dynamicConfig = useIndicatorConfig();
  const { catalog, loaded: catalogLoaded } = dynamicConfig;

  const hasData = rows.some((r) => r.rowType === "oracle");
  const isLocked = lockedDate !== null && lockedDate === fetchedDate;
  // Сонгосон сард riskbranch дата ороогүй эсэх (дата ирсэн жагсаалтаас шалгана)
  const monthHasNoData =
    !!selectedMonth &&
    riskbranchDates.length > 0 &&
    !riskbranchDates.some((d) => monthKeyFromDate(d) === selectedMonth);

  const handleManualSave = useCallback(
    (branchId: string, indicatorId: string, value: number) => {
      setManualMap((prev) => {
        const next = { ...prev };
        const branch = { ...(next[branchId] || {}) };
        if (!value || value <= 0) delete branch[indicatorId];
        else branch[indicatorId] = Math.min(5, Math.max(0, value));
        if (Object.keys(branch).length === 0) delete next[branchId];
        else next[branchId] = branch;
        return next;
      });
      const key = `${branchId}::${indicatorId}`;
      clearTimeout(manualTimers.current[key]);
      manualTimers.current[key] = setTimeout(() => {
        riskApi
          .upsertManualIndicator({ branchId, indicatorId, value })
          .catch(showSaveError);
      }, 600);
    },
    [showSaveError],
  );

  // Init: lock check + load locked date if exists, otherwise closest available
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [{ lockedDate: ld }, dates, manualData] = await Promise.all([
          riskApi.getRiskbranchLock(),
          riskApi.listRiskbranchDates(),
          riskApi.listManualIndicators(),
        ]);
        if (cancelled) return;
        setLockedDate(ld);
        setManualMap(manualData || {});
        setRiskbranchDates(dates);

        const targetDate =
          ld ??
          (() => {
            if (dates.length === 0) return null;
            const today = new Date().toISOString().slice(0, 10);
            if (dates.includes(today)) return today;
            return dates.reduce((closest, d) =>
              Math.abs(new Date(d).getTime() - Date.now()) <
              Math.abs(new Date(closest).getTime() - Date.now())
                ? d
                : closest,
            );
          })();

        if (targetDate) {
          setSelectedDate(targetDate);
          setSelectedMonth(monthKeyFromDate(targetDate));
          // Backend fill-forward: res.fetchedDate нь бодит anchor (хамгийн ойрын data)
          const res = await riskApi.getRiskbranch(targetDate);
          if (cancelled) return;
          const actualDate = res.fetchedDate || targetDate;
          const [judgeList, allJudge] = await Promise.all([
            riskApi.listJudgements(actualDate),
            riskApi.listJudgements(),
          ]);
          if (cancelled) return;
          setRows(res.rows ?? []);
          setFetchedDate(actualDate);
          const solids = oracleSolidsFromRows(res.rows ?? []);
          const { scores: jmap, comments: cmap } =
            judgementsFromListForBranches(judgeList, solids);
          setJudgements(jmap);
          setJudgementComments(cmap);
          const closestPrevDate = allJudge.find(
            (j) => j.fetchedDate < actualDate,
          )?.fetchedDate;
          const prevMap: Record<string, number> = {};
          if (closestPrevDate) {
            for (const j of allJudge) {
              if (j.fetchedDate === closestPrevDate && j.score > 0) {
                prevMap[j.branchId] = j.score;
              }
            }
          }
          if (!cancelled) setPrevJudgements(prevMap);
        }
      } catch (e: unknown) {
        if (!cancelled) setErrorMsg(getApiErrorMessage(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Load Date function
  const loadDate = useCallback(async (date: string) => {
    if (!date) return;
    loadAbortRef.current?.abort();
    const abort = new AbortController();
    loadAbortRef.current = abort;

    // Хуучин хүснэгтийг бүү нуу — шинэ оноо ирэхэд мөрүүдээ шинэчилнэ.
    setLoadingDate(true);
    setErrorMsg(null);
    try {
      // Backend fill-forward: res.fetchedDate нь бодит anchor (хамгийн ойрын data)
      const res = await riskApi.getRiskbranch(date);
      if (abort.signal.aborted) return;
      const actualDate = res.fetchedDate || date;
      const [judgeList, allJudge] = await Promise.all([
        riskApi.listJudgements(actualDate),
        riskApi.listJudgements(),
      ]);
      if (abort.signal.aborted) return;
      const nextRows = res.rows ?? [];
      setFetchedDate(actualDate);
      setRows(nextRows);
      const solids = oracleSolidsFromRows(nextRows);
      const { scores: jmap, comments: cmap } = judgementsFromListForBranches(
        judgeList,
        solids,
      );
      setJudgements(jmap);
      setJudgementComments(cmap);
      const closestPrevDate = allJudge.find(
        (j) => j.fetchedDate < actualDate,
      )?.fetchedDate;
      const prevMap: Record<string, number> = {};
      if (closestPrevDate) {
        for (const j of allJudge) {
          if (j.fetchedDate === closestPrevDate && j.score > 0) {
            prevMap[j.branchId] = j.score;
          }
        }
      }
      if (!abort.signal.aborted) setPrevJudgements(prevMap);
    } catch (e: unknown) {
      if (abort.signal.aborted) return;
      setErrorMsg(getApiErrorMessage(e));
    } finally {
      if (!abort.signal.aborted) setLoadingDate(false);
    }
  }, []);

  // Сар сонгоход тухайн сарын бодит дата (fetchedDate) байвал түүнийг ачаална.
  // Дата ороогүй бол хуучин сар руу fill-forward ХИЙХГҮЙ — "дата байхгүй" гэж
  // харуулна (дата сард нэг удаа ордог тул сарын нарийвчлал хангалттай).
  const loadMonth = useCallback(
    (monthKey: string) => {
      setSelectedMonth(monthKey);
      if (!monthKey) return;
      const datesInMonth = riskbranchDatesRef.current.filter(
        (d) => monthKeyFromDate(d) === monthKey,
      );
      if (datesInMonth.length === 0) {
        loadAbortRef.current?.abort();
        setRows([]);
        setFetchedDate("");
        setSelectedDate("");
        setJudgements({});
        setJudgementComments({});
        setLoadingDate(false);
        setErrorMsg(null);
        return;
      }
      const latest = [...datesInMonth].sort().pop() as string;
      setSelectedDate(latest);
      loadDate(latest);
    },
    [loadDate],
  );

  // Lock / Unlock Date
  const toggleLock = useCallback(async () => {
    if (!fetchedDate) return;
    setLockingDate(true);
    try {
      if (isLocked) {
        await riskApi.unlockRiskbranchDate(fetchedDate);
        setLockedDate(null);
      } else {
        if (lockedDate) await riskApi.unlockRiskbranchDate(lockedDate);
        await riskApi.lockRiskbranchDate(fetchedDate);
        setLockedDate(fetchedDate);
      }
    } catch (e: unknown) {
      setErrorMsg(getApiErrorMessage(e));
    } finally {
      setLockingDate(false);
    }
  }, [fetchedDate, isLocked, lockedDate]);

  // Handle inline judgement updates
  const handleJudgementChange = useCallback(
    (branchId: string, branchName: string, score: number) => {
      setJudgements((prev) => {
        if (score <= 0) {
          const next = { ...prev };
          delete next[branchId];
          return next;
        }
        return { ...prev, [branchId]: score };
      });
      if (score <= 0) {
        setJudgementComments((prev) => {
          const next = { ...prev };
          delete next[branchId];
          return next;
        });
      }
      if (judgementTimers.current[branchId])
        clearTimeout(judgementTimers.current[branchId]);
      judgementTimers.current[branchId] = setTimeout(() => {
        riskApi
          .upsertJudgement({
            branchId,
            branchName,
            fetchedDate,
            score,
            comment:
              score <= 0 ? "" : (judgementCommentsRef.current[branchId] ?? ""),
          })
          .catch(showSaveError);
      }, 600);
    },
    [fetchedDate, showSaveError],
  );

  const handleJudgementCommentSave = useCallback(
    (branchId: string, branchName: string, comment: string) => {
      const trimmed = comment.trim();
      setJudgementComments((prev) => {
        const next = { ...prev };
        if (!trimmed) delete next[branchId];
        else next[branchId] = trimmed;
        return next;
      });
      const score = judgements[branchId] ?? 0;
      if (score <= 0) return;
      riskApi
        .upsertJudgement({
          branchId,
          branchName,
          fetchedDate,
          score,
          comment: trimmed,
        })
        .catch(showSaveError);
    },
    [fetchedDate, judgements, showSaveError],
  );

  // saveIndicatorFn adapter: ReportView нь (branchId, indicatorId, value) дуудна,
  // judgment indicator байвал upsertJudgement API-руу дамжуулна
  // onJudgementSave: indicator ID-тай холбоогүй, зөвхөн branchId + score
  const onJudgementSave = useCallback(
    (branchId: string, score: number) => {
      const branchRow = rows.find(
        (r) => r.rowType === "oracle" && String(r.SOLID || "") === branchId,
      );
      const branchName = branchRow
        ? String(branchRow.BRANCHNAME ?? branchRow.SOLID ?? branchId)
        : branchId;
      handleJudgementChange(branchId, branchName, score);
    },
    [rows, handleJudgementChange],
  );

  const onJudgementCommentSave = useCallback(
    (branchId: string, comment: string) => {
      const branchRow = rows.find(
        (r) => r.rowType === "oracle" && String(r.SOLID || "") === branchId,
      );
      const branchName = branchRow
        ? String(branchRow.BRANCHNAME ?? branchRow.SOLID ?? branchId)
        : branchId;
      handleJudgementCommentSave(branchId, branchName, comment);
    },
    [rows, handleJudgementCommentSave],
  );

  const scoredRows = useMemo(() => toScored(rows, catalog), [rows, catalog]);

  return (
    <div className="min-h-0 flex-1 w-full min-w-0 max-w-full overflow-x-hidden bg-gradient-to-br from-background via-background to-rose-500/[0.02] text-foreground flex flex-col">
      <ToolPageHeader
        href="/tools/risk-assessment"
        icon={<ClipboardEdit className="w-4 h-4 text-rose-500" />}
        title={t("riskWorkPageTitle")}
        rightContent={
          <div className="flex items-center gap-2">
            {/* Аргачлал — бүх үзүүлэлтийн үнэлгээний аргачлалыг унших */}
            <Link
              href="/tools/risk-assessment/argachlal"
              title={t("raWorkPageMethodologyTooltip")}
              className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border border-border bg-muted/30 text-xs font-semibold text-muted-foreground hover:bg-muted/60 hover:text-foreground transition-all"
            >
              <BookOpen className="w-3.5 h-3.5" />
              {t("admRiskIndMethodologyLabel")}
            </Link>

            {/* Сарын сонголт — дата сард нэг удаа ордог тул өдрөөр биш сараар */}
            <MonthFilter
              value={selectedMonth}
              onChange={loadMonth}
              extraOptions={riskbranchDates.map(monthKeyFromDate)}
              emphasis="primary"
              allowClear={false}
              ariaLabel={t("monthFilterAriaLabel")}
            />

            {/* Indicator Filter toggle */}
            {hasData && (
              <button
                onClick={() => setFilterOpen((v) => !v)}
                className={`flex items-center gap-1.5 h-7 px-2.5 rounded-md border text-xs font-semibold transition-all ${
                  filterOpen
                    ? "border-rose-500/60 bg-rose-500/15 text-rose-600 dark:text-rose-400"
                    : "border-border bg-muted/30 text-muted-foreground hover:bg-muted/60"
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                {t("raWorkPageFilterBtn")}
              </button>
            )}

            {/* Lock / Unlock */}
            {hasData && (
              <button
                onClick={toggleLock}
                disabled={lockingDate}
                title={
                  isLocked
                    ? `${fetchedDate} ${t("raWorkPageUnlockAction")}`
                    : `${fetchedDate} ${t("raWorkPageLockAction")}`
                }
                aria-label={isLocked ? "Unlock" : "Lock"}
                className={`inline-flex items-center justify-center h-7 w-7 rounded-md border transition-all disabled:opacity-40 ${
                  isLocked
                    ? "border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400"
                    : "border-border bg-muted/30 text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                }`}
              >
                {lockingDate ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : isLocked ? (
                  <Lock className="w-3.5 h-3.5" />
                ) : (
                  <LockOpen className="w-3.5 h-3.5" />
                )}
              </button>
            )}

            {/* Prominent Save Completed Report Button */}
            {hasData && isLocked && (
              <button
                onClick={() => saveModalOpenHandler({ pDate: fetchedDate })}
                className="flex items-center gap-1.5 h-7 px-3 rounded-md bg-amber-600 hover:bg-amber-500 text-foreground text-xs font-semibold transition-all"
              >
                <BookmarkPlus className="w-3.5 h-3.5" />
                {t("raWorkPageSaveReportBtn")}
              </button>
            )}
          </div>
        }
      />
      <div className="container mx-auto px-4 py-6 space-y-4 flex-1 min-w-0 w-full max-w-[1800px]">
        {errorMsg && (
          <div className="rounded-xl border border-red-500/30 bg-gradient-to-r from-red-500/10 to-rose-500/5 p-4 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs text-red-600/80">{errorMsg}</div>
            <button
              onClick={() => setErrorMsg(null)}
              className="text-muted-foreground hover:text-foreground text-xs"
            >
              ✕
            </button>
          </div>
        )}

        {loading && !hasData ? (
          <ReportSkeleton rows={10} />
        ) : monthHasNoData ? (
          <div className="rounded-2xl border border-border bg-card shadow-premium ring-hairline px-6 py-16 text-center">
            <div className="inline-flex w-14 h-14 rounded-2xl bg-muted/50 border border-border items-center justify-center mb-3">
              <Activity className="w-6 h-6 text-muted-foreground/60" />
            </div>
            <div className="text-sm font-semibold text-muted-foreground">
              {formatMonthMn(selectedMonth)}-д дата ороогүй байна
            </div>
            <div className="text-xs text-muted-foreground/60 mt-1">
              Тухайн сарын дата хараахан ороогүй байна. Өөр сар сонгоно уу.
            </div>
          </div>
        ) : !hasData ? (
          <div className="rounded-2xl border border-border bg-card shadow-premium ring-hairline px-6 py-16 text-center">
            <div className="inline-flex w-14 h-14 rounded-2xl bg-muted/50 border border-border items-center justify-center mb-3">
              <Activity className="w-6 h-6 text-muted-foreground/60" />
            </div>
            <div className="text-sm font-semibold text-muted-foreground">
              {fetchedDate
                ? `${fetchedDate} ${t("raWorkPageNoDataForDate")}`
                : t("raWorkPageEnterDateHint")}
            </div>
            {!fetchedDate && (
              <div className="text-xs text-muted-foreground/60 mt-1">
                {t("raWorkPageSelectDateAboveHint")}
              </div>
            )}
          </div>
        ) : (
          <>
            {filterOpen && (
              <IndicatorFilterPanel
                rows={rows}
                catalog={catalog}
                catalogLoaded={catalogLoaded}
                manualMap={manualMap}
                externalJudgements={judgements}
                selectedIndId={filterIndId}
                onSelectInd={setFilterIndId}
                onClose={() => setFilterOpen(false)}
              />
            )}
            <div className={loadingDate ? "pointer-events-none" : undefined}>
              <ReportView
                scoredRows={scoredRows}
                riskFilter={riskFilter}
                setRiskFilter={setRiskFilter}
                pDate={fetchedDate}
                dataReferenceDate={selectedDate}
                initialManualMap={manualMap}
                saveIndicatorFn={handleManualSave}
                externalJudgements={judgements}
                externalJudgementComments={judgementComments}
                onJudgementChange={onJudgementSave}
                onJudgementCommentSave={onJudgementCommentSave}
                previousJudgements={prevJudgements}
                hideComparison={true}
                hideUnevaluatedInDetail={true}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function RiskWorkPage() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveModalMeta, setSaveModalMeta] = useState<SaveModalMeta>({
    pDate: "",
  });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const doSaveHistory = useCallback(async () => {
    const name = saveName.trim();
    if (!name) return;
    setSaving(true);
    setErrorMsg(null);
    try {
      await riskApi.saveHistoryFromRiskbranch(saveModalMeta.pDate, name);
      setSaveModalOpen(false);
      setSaveName("");
      toast({
        title: t("success"),
        description: t("riskSaveSuccess"),
      });
    } catch (e: unknown) {
      setErrorMsg(getApiErrorMessage(e) || t("riskSaveError"));
    } finally {
      setSaving(false);
    }
  }, [saveName, saveModalMeta, t, toast]);

  return (
    <>
      <MonitorContent
        saveModalOpenHandler={(meta) => {
          setSaveModalMeta(meta);
          setSaveName(meta.pDate);
          setSaveModalOpen(true);
        }}
      />

      {/* Save modal */}
      {saveModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={() => setSaveModalOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-card shadow-premium-xl ring-hairline p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
                <BookmarkPlus className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">
                  {t("raWorkPageSaveModalTitle")}
                </h3>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  {t("raWorkPageSelectedDateLabel")} {saveModalMeta.pDate}
                </p>
              </div>
            </div>
            {errorMsg && (
              <div className="mb-3 text-xs text-red-500 border border-red-500/20 bg-red-500/10 p-2 rounded-lg">
                {errorMsg}
              </div>
            )}
            <input
              type="text"
              value={saveName}
              onChange={(e) => setSaveName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && doSaveHistory()}
              placeholder={t("riskSavePlaceholder")}
              autoFocus
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            />
            <div className="flex justify-end gap-2 mt-4">
              <button
                onClick={() => setSaveModalOpen(false)}
                className="px-4 py-1.5 rounded-lg border border-border text-xs hover:bg-muted/40 transition-colors"
              >
                {t("cancel")}
              </button>
              <button
                onClick={doSaveHistory}
                disabled={saving || !saveName.trim()}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-foreground text-xs font-semibold disabled:opacity-40 transition-all"
              >
                {saving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {t("save")}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
