"use client";

import { useState, useEffect, useCallback } from "react";
import { dbAccessApi, getApiErrorMessage } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import ToolPageHeader from "@/components/shared/ToolPageHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  CheckCircle2,
  Loader2,
  RefreshCw,
  Database,
  Clock,
  Copy,
  Eye,
  EyeOff,
  XCircle,
} from "lucide-react";

interface ActiveGrant {
  id: string;
  requestId: string;
  userUserId: string;
  tableName: string;
  columns: string[];
  accessTypes: string[];
  validUntil: string;
  grantedByName: string;
  grantedAt: string;
  isActive: boolean;
  chPassword: string;
}

interface GrantGroup {
  requestId: string;
  grantIds: string[];
  userUserId: string;
  tables: string[];
  columns: string[];
  accessTypes: string[];
  validUntil: string;
  grantedByName: string;
  grantedAt: string;
  chPassword: string;
}

function groupGrants(grants: ActiveGrant[]): GrantGroup[] {
  const map = new Map<string, GrantGroup>();
  for (const g of grants) {
    const key = g.requestId || g.id;
    if (!map.has(key)) {
      map.set(key, {
        requestId: key,
        grantIds: [],
        userUserId: g.userUserId,
        tables: [],
        columns: g.columns,
        accessTypes: g.accessTypes,
        validUntil: g.validUntil,
        grantedByName: g.grantedByName,
        grantedAt: g.grantedAt,
        chPassword: g.chPassword,
      });
    }
    const grp = map.get(key)!;
    grp.grantIds.push(g.id);
    if (!grp.tables.includes(g.tableName)) grp.tables.push(g.tableName);
  }
  return Array.from(map.values());
}

function daysLeft(dateStr: string): number {
  const diff = new Date(dateStr).getTime() - Date.now();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

/** Format DateTime as "YYYY.MM.DD HH:mm" (24h) */
function fmt24(dateStr: string): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleString("mn-MN", {
    timeZone: "Asia/Ulaanbaatar",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

export default function MyGrantsPage() {
  const { toast } = useToast();
  const { t } = useLanguage();

  const [grants, setGrants] = useState<ActiveGrant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPwd, setShowPwd] = useState<Record<string, boolean>>({});
  const [cancelingId, setCancelingId] = useState<string | null>(null);

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: `${label} хуулагдлаа`, duration: 1500 });
  };

  const handleCancel = async (group: GrantGroup) => {
    const tblList = group.tables.join(", ");
    if (
      !confirm(
        `"${tblList}" хандалтын эрхийг хаах уу? Та ClickHouse-руу нэвтрэх боломжгүй болно.`,
      )
    )
      return;
    try {
      setCancelingId(group.requestId);
      // Cancel every grant row belonging to this request
      await Promise.all(
        group.grantIds.map((id) => dbAccessApi.cancelMyGrant(id)),
      );
      toast({
        title: "✅ Эрх хаагдлаа",
        description: "ClickHouse хандалт цуцлагдлаа",
      });
      await load();
    } catch (err: unknown) {
      toast({
        title: "Алдаа",
        description: getApiErrorMessage(err) || "Хаахад алдаа гарлаа",
        variant: "destructive",
      });
    } finally {
      setCancelingId(null);
    }
  };

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const data = await dbAccessApi.getMyGrants();
      setGrants(data);
    } catch {
      toast({
        title: "Алдаа",
        description: "Эрхүүдийг ачаалахад алдаа гарлаа",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="min-h-screen bg-background">
      <ToolPageHeader
        href="/tools/db-access"
        icon={
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md">
            <CheckCircle2 className="w-3.5 h-3.5 text-foreground" />
          </div>
        }
        title={t("myGrantsTitle")}
        subtitle={t("myGrantsSubtitle")}
        rightContent={
          <Button variant="ghost" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        }
      />
      <div className="max-w-3xl mx-auto space-y-6 p-4 md:p-8">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : grants.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 rounded-xl border bg-card text-muted-foreground">
            <Database className="h-12 w-12 opacity-20" />
            <p className="font-medium">{t("myGrantsEmpty")}</p>
            <p className="text-sm">{t("myGrantsEmptyHint")}</p>
            <Link href="/tools/db-access">
              <Button variant="outline" size="sm" className="mt-1">
                {t("myGrantsRequestBtn")}
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {groupGrants(grants).map((grp) => {
              const days = daysLeft(grp.validUntil);
              const expiringSoon = days <= 3;
              const expired = days <= 0;

              return (
                <div
                  key={grp.requestId}
                  className={`rounded-xl border bg-card p-5 space-y-3 ${
                    expired
                      ? "border-red-500/30 opacity-60"
                      : expiringSoon
                        ? "border-amber-500/40"
                        : ""
                  }`}
                >
                  {/* Header row */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0">
                        <Database className="h-4 w-4 text-cyan-400" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">
                          {t("myGrantsGrantedBy")} {grp.grantedByName}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap justify-end">
                      <div className="flex gap-1.5 flex-wrap">
                        {grp.accessTypes.map((a) => (
                          <Badge
                            key={a}
                            className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
                            variant="outline"
                          >
                            {a}
                          </Badge>
                        ))}
                      </div>
                      {!expired && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:bg-destructive/10 gap-1 h-7 px-2"
                          disabled={cancelingId === grp.requestId}
                          onClick={() => handleCancel(grp)}
                          title={t("myGrantsCloseTitle")}
                        >
                          {cancelingId === grp.requestId ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <XCircle className="h-3.5 w-3.5" />
                          )}
                          <span className="text-xs">
                            {t("myGrantsCloseBtn")}
                          </span>
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Table list */}
                  <div className="flex flex-wrap gap-1.5">
                    {grp.tables.map((t) => (
                      <span
                        key={t}
                        className="inline-flex items-center gap-1 text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 px-2 py-0.5 rounded-md"
                      >
                        <Database className="h-3 w-3" />
                        {t}
                      </span>
                    ))}
                  </div>

                  {/* Time info */}
                  <div
                    className="flex flex-wrap gap-4 text-sm text-muted-foreground"
                    suppressHydrationWarning
                  >
                    <div className="flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5" />
                      <span suppressHydrationWarning>
                        {expired ? (
                          <span className="text-red-400">
                            {t("myGrantsExpired")}
                          </span>
                        ) : expiringSoon ? (
                          <span className="text-amber-400">
                            {days} {t("myGrantsDaysLeft")}
                          </span>
                        ) : (
                          `${days} ${t("myGrantsDaysLeft")}`
                        )}
                      </span>
                    </div>
                    <span suppressHydrationWarning>
                      {t("myGrantsExpiresLabel")}{" "}
                      <strong>{fmt24(grp.validUntil)}</strong>
                    </span>
                    <span suppressHydrationWarning>
                      {t("myGrantsGrantedBy")} {fmt24(grp.grantedAt)}
                    </span>
                  </div>

                  {/* ClickHouse credentials */}
                  {grp.chPassword && (
                    <div className="rounded-lg border border-cyan-500/20 bg-cyan-500/5 p-3 space-y-2">
                      <p className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
                        {t("myGrantsChCreds")}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-20 shrink-0">
                          {t("myGrantsChUser")}
                        </span>
                        <code className="text-xs font-mono bg-muted px-2 py-0.5 rounded flex-1">
                          {grp.userUserId}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() =>
                            copyText(grp.userUserId, t("myGrantsCopyUser"))
                          }
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-20 shrink-0">
                          {t("myGrantsChPassword")}
                        </span>
                        <code className="text-xs font-mono bg-muted px-2 py-0.5 rounded flex-1 tracking-widest">
                          {showPwd[grp.requestId]
                            ? grp.chPassword
                            : "••••••••••••••••"}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() =>
                            setShowPwd((p) => ({
                              ...p,
                              [grp.requestId]: !p[grp.requestId],
                            }))
                          }
                        >
                          {showPwd[grp.requestId] ? (
                            <EyeOff className="h-3 w-3" />
                          ) : (
                            <Eye className="h-3 w-3" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() =>
                            copyText(grp.chPassword, t("myGrantsCopyPwd"))
                          }
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
