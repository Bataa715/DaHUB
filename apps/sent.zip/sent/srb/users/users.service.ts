import {
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from "@nestjs/common";
import { ClickHouseService } from "../clickhouse/clickhouse.service";
import { AuthService } from "../auth/auth.service";
import { UpdateUserDto } from "./dto/update-user.dto";
import * as bcrypt from "bcryptjs";
import { VALID_TOOLS_SET } from "../common/constants/tools";
import { assertRealImage } from "../common/utils/image-signature";

/** `data:image/<төрөл>;base64,<өгөгдөл>` угтварыг задлана. */
const IMAGE_DATA_URI_RE = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i;
import {
  buildUserId,
  buildUsersTableRow,
  safeParseTools,
  webVisibleUserSql,
  isPrivilegedUser,
} from "../common/utils/user-utils";

// [LOW-1] buildUserId and safeParseTools moved to src/common/utils/user-utils.ts

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(
    private clickhouse: ClickHouseService,
    private authService: AuthService,
  ) {}

  async findAll(limit = 1000, offset = 0, excludeAdmins = false) {
    const adminFilter = excludeAdmins ? `WHERE ${webVisibleUserSql("u")}` : "";
    // [PERF] profileImage-ийг (base64 data URI, нэг бүр 7MB хүртэл) жагсаалтад
    // буцаахгүй. Хэрэглэгчийн жагсаалт (admin) аль нь ч зураг харуулдаггүй мөртлөө
    // өмнө нь `SELECT u.*` бүх хэрэглэгчийн бүтэн зургийг татдаг байсан — хэдэн
    // арван MB payload болж prod дээр хуудсыг маш удаан болгодог байв (localhost
    // дээр мэдрэгддэггүй). Оронд нь hasProfileImage туг л буцаана; бодит зураг
    // хэрэгтэй бол /users/:id-ээр нэг бүрчлэн авна. Тодорхой багана сонгосон нь
    // мөн password зэрэг ашиглагдаагүй талбарыг татахаас сэргийлнэ.
    const users = await this.clickhouse.query<any>(
      `SELECT u.id, u.userId, u.name, u.position, u.departmentId,
              u.isAdmin, u.isSuperAdmin, u.isActive, u.allowedTools,
              u.lastLoginAt, u.createdAt, u.isLocked, u.failedLoginCount,
              if(u.profileImage != '', 1, 0) AS hasProfileImage,
              d.name AS departmentName
       FROM users u LEFT JOIN departments d ON u.departmentId = d.id
       ${adminFilter}
       ORDER BY u.createdAt DESC
       LIMIT {limit:UInt32} OFFSET {offset:UInt32}`,
      { limit, offset },
    );

    return users.map((user) => ({
      id: user.id,
      userId: user.userId,
      name: user.name,
      position: user.position,
      hasProfileImage: !!Number(user.hasProfileImage),
      department: user.departmentName,
      departmentId: user.departmentId,
      isAdmin: !!user.isAdmin,
      isSuperAdmin: !!user.isSuperAdmin,
      isActive: !!user.isActive,
      allowedTools: safeParseTools(user.allowedTools),
      lastLoginAt: user.lastLoginAt,
      createdAt: user.createdAt,
      isLocked: !!user.isLocked,
      failedLoginCount: Number(user.failedLoginCount) || 0,
    }));
  }

  /** [PERF] Зөвхөн profileImage-ийг (base64 data URI) авах хөнгөн query —
   *  avatar endpoint нэг хэрэглэгчийн зургийг binary болгож үйлчлэхэд ашиглана.
   *  Жагсаалтын query-үүд зургийг татдаггүй болсон (hasProfileImage л буцаана). */
  async getProfileImage(id: string): Promise<string | null> {
    const rows = await this.clickhouse.query<{ profileImage?: string }>(
      "SELECT profileImage FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );
    const img = rows[0]?.profileImage;
    return img && String(img).startsWith("data:") ? String(img) : null;
  }

  async findOne(id: string) {
    const users = await this.clickhouse.query<any>(
      `SELECT u.*, d.name as departmentName
       FROM users u LEFT JOIN departments d ON u.departmentId = d.id
       WHERE u.id = {id:String} LIMIT 1`,
      { id },
    );

    const user = users[0];
    if (!user) {
      throw new NotFoundException("Хэрэглэгч олдсонгүй");
    }

    return {
      id: user.id,
      userId: user.userId,
      name: user.name,
      position: user.position,
      profileImage: user.profileImage,
      department: user.departmentName,
      departmentId: user.departmentId,
      isAdmin: !!user.isAdmin,
      isSuperAdmin: !!user.isSuperAdmin,
      allowedTools: safeParseTools(user.allowedTools),
      createdAt: user.createdAt,
    };
  }

  async getAdmins() {
    const users = await this.clickhouse.query<any>(
      `SELECT u.id, u.userId, u.name, u.departmentId, u.isAdmin, u.isSuperAdmin, u.isActive,
              u.grantableTools, u.createdAt, d.name AS departmentName
       FROM users u
       LEFT JOIN departments d ON u.departmentId = d.id
       WHERE u.isAdmin = 1
       ORDER BY u.createdAt ASC`,
    );
    return users.map((user) => ({
      id: user.id,
      userId: user.userId,
      name: user.name,
      department: user.departmentName ?? null,
      isAdmin: !!user.isAdmin,
      isSuperAdmin: !!user.isSuperAdmin,
      isActive: !!user.isActive,
      grantableTools: safeParseTools(user.grantableTools),
      createdAt: user.createdAt,
    }));
  }

  private async replaceUser(
    id: string,
    existing: Record<string, any>,
    overrides: Record<string, unknown> = {},
  ) {
    await this.clickhouse.replaceRows("users", "id = {id:String}", { id }, [
      buildUsersTableRow(existing, overrides),
    ]);
    // Bust the auth-layer validateUser cache so any change (deactivation, tools,
    // admin role, password/lock) takes effect on the user's very next request.
    this.authService.invalidateUserValidation(id);
  }

  async setAdminRole(
    id: string,
    isAdmin: boolean,
    isSuperAdmin: boolean,
    grantableTools?: string[],
  ) {
    const users = await this.clickhouse.query<any>(
      "SELECT * FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );
    if (users.length === 0) throw new NotFoundException("Хэрэглэгч олдсонгүй");

    // [H-5] Only persist known-valid tool names (see common/constants/tools.ts)
    const sanitizedTools = (grantableTools ?? []).filter((t) =>
      VALID_TOOLS_SET.has(t),
    );
    const toolsJson = JSON.stringify(sanitizedTools);

    await this.replaceUser(id, users[0], {
      isAdmin: isAdmin ? 1 : 0,
      isSuperAdmin: isSuperAdmin ? 1 : 0,
      grantableTools: toolsJson,
      // Админ болгоход хэлтэсээс салгана — веб дээр харагдахгүй
      ...(isAdmin ? { departmentId: "" } : {}),
    });

    return {
      message: "Амжилттай",
      id,
      isAdmin,
      isSuperAdmin,
      grantableTools: sanitizedTools,
    };
  }

  async update(id: string, updateUserDto: UpdateUserDto) {
    const users = await this.clickhouse.query<any>(
      "SELECT * FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );

    if (users.length === 0) {
      throw new NotFoundException("Хэрэглэгч олдсонгүй");
    }

    const existing = users[0];
    const isPrivileged = !!existing.isAdmin || !!existing.isSuperAdmin;

    const nextName = updateUserDto.name ?? existing.name;
    const nextPosition =
      updateUserDto.position !== undefined
        ? updateUserDto.position
        : (existing.position ?? "");
    let nextUserId =
      updateUserDto.userId !== undefined
        ? updateUserDto.userId
        : existing.userId;
    const nextDepartmentId =
      updateUserDto.departmentId !== undefined
        ? updateUserDto.departmentId
        : (existing.departmentId ?? "");
    const nextProfileImage =
      updateUserDto.profileImage !== undefined
        ? updateUserDto.profileImage
        : (existing.profileImage ?? "");
    const nextAllowedTools =
      updateUserDto.allowedTools !== undefined
        ? JSON.stringify(updateUserDto.allowedTools)
        : typeof existing.allowedTools === "string"
          ? existing.allowedTools
          : JSON.stringify(existing.allowedTools ?? []);

    if (updateUserDto.departmentId !== undefined) {
      if (isPrivileged) {
        throw new BadRequestException(
          "Админ хэрэглэгчийг хэлтэст оноох боломжгүй",
        );
      }

      // Auto-generate userId only when not explicitly provided
      if (updateUserDto.userId === undefined) {
        const depts = await this.clickhouse.query<any>(
          "SELECT name, code FROM departments WHERE id = {deptId:String} LIMIT 1",
          { deptId: updateUserDto.departmentId },
        );
        if (depts.length > 0) {
          const newDeptName = depts[0].name as string;
          const newDeptCode = (depts[0].code as string) || "";
          nextUserId = buildUserId(
            newDeptName,
            nextName,
            newDeptCode,
            nextPosition,
          );
        }
      }
    }

    if (updateUserDto.profileImage !== undefined) {
      if (updateUserDto.profileImage.length > 7_000_000) {
        throw new BadRequestException(
          "Профайл зургийн хэмжээ хэт их байна (дээд тал нь 5MB)",
        );
      }
      // [AUDIT] DTO-ийн @Matches нь ЗАРЛАСАН `data:image/...` угтварыг л
      // шалгадаг — агуулга нь ямар ч байж болно. Хоосон утга нь зургийг
      // устгах гэсэн үг тул түүнийг алгасна.
      if (updateUserDto.profileImage !== "") {
        const m = IMAGE_DATA_URI_RE.exec(updateUserDto.profileImage);
        if (!m) {
          throw new BadRequestException("Профайл зургийн формат буруу байна");
        }
        assertRealImage(Buffer.from(m[2], "base64"), m[1]);
      }
    }

    const hasChanges =
      updateUserDto.name !== undefined ||
      updateUserDto.position !== undefined ||
      updateUserDto.userId !== undefined ||
      updateUserDto.departmentId !== undefined ||
      updateUserDto.profileImage !== undefined ||
      updateUserDto.allowedTools !== undefined;

    if (hasChanges) {
      try {
        await this.replaceUser(id, existing, {
          userId: nextUserId,
          name: nextName,
          position: nextPosition,
          profileImage: nextProfileImage,
          departmentId: nextDepartmentId,
          allowedTools: nextAllowedTools,
        });
      } catch (error: unknown) {
        this.logger.error(
          `ClickHouse update error: ${error instanceof Error ? error.message : String(error)}`,
        );
        const msg = error instanceof Error ? error.message : String(error);
        throw new Error(`Хэрэглэгч шинэчлэхэд алдаа гарлаа: ${msg}`);
      }
    }

    const updated = await this.clickhouse.query<any>(
      `SELECT u.*, d.name as departmentName
       FROM users u LEFT JOIN departments d ON u.departmentId = d.id
       WHERE u.id = {id:String} LIMIT 1`,
      { id },
    );

    const user = updated[0];
    return {
      id: user.id,
      name: user.name,
      position: user.position,
      profileImage: user.profileImage,
      department: user.departmentName,
      departmentId: user.departmentId,
      isAdmin: !!user.isAdmin,
      allowedTools: safeParseTools(user.allowedTools),
    };
  }

  async clearProfileImage(id: string) {
    return this.update(id, { profileImage: "" });
  }

  /**
   * [H-6] A plain Admin (isAdmin=1, isSuperAdmin=0) must not be able to delete,
   * deactivate, or reset the password of another admin/superadmin — only a
   * SuperAdmin may manage privileged accounts. Regular users are unaffected.
   */
  private assertCanManageTarget(
    target: { isAdmin?: unknown; isSuperAdmin?: unknown },
    callerIsSuperAdmin: boolean,
  ): void {
    if (isPrivilegedUser(target) && !callerIsSuperAdmin) {
      throw new ForbiddenException(
        "Зөвхөн супер админ бусад админ хэрэглэгчийг удирдах боломжтой",
      );
    }
  }

  async remove(id: string, callerIsSuperAdmin: boolean) {
    const users = await this.clickhouse.query<any>(
      "SELECT id, isAdmin, isSuperAdmin FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );

    if (users.length === 0) {
      throw new NotFoundException("Хэрэглэгч олдсонгүй");
    }
    this.assertCanManageTarget(users[0], callerIsSuperAdmin);

    // Hard-delete synchronously — soft UPDATE isActive bypass (no ALTER UPDATE privilege)
    await this.clickhouse.exec(
      "ALTER TABLE users DELETE WHERE id = {id:String} SETTINGS mutations_sync = 1",
      { id },
    );
    this.authService.invalidateUserValidation(id);
    return { message: "Хэрэглэгчийг амжилттай устгалаа" };
  }

  async updateTools(
    id: string,
    requestedTools: string[],
    caller: { isSuperAdmin: boolean; grantableTools: string[] },
  ) {
    const users = await this.clickhouse.query<any>(
      "SELECT * FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );

    if (users.length === 0) {
      throw new NotFoundException("Хэрэглэгч олдсонгүй");
    }

    if (isPrivilegedUser(users[0])) {
      throw new BadRequestException(
        "Админ хэрэглэгчид tool эрх олгох боломжгүй",
      );
    }

    // [ACCESS] Энгийн (super биш) admin нь зөвхөн ӨӨРИЙН grantableTools (super
    // admin-ий тохируулсан) доторх tool-ыг олгож/хасаж чадна. Scope-оос гадуурх
    // tool-ыг зорилтот хэрэглэгч аль хэдийн эзэмшсэн бол ХЭВЭЭР хадгална — sub
    // admin эрхгүй tool-оо олгож ч чадахгүй, өөр admin-ий олгосон tool-ыг ч
    // хасаж чадахгүй. Super admin бүрэн хяналттай.
    const existing = safeParseTools(users[0].allowedTools);
    let finalTools: string[];
    if (caller.isSuperAdmin) {
      finalTools = requestedTools;
    } else {
      const grantable = new Set(caller.grantableTools ?? []);
      const preserved = existing.filter((t) => !grantable.has(t));
      const withinScope = requestedTools.filter((t) => grantable.has(t));
      finalTools = Array.from(new Set([...preserved, ...withinScope]));
    }

    await this.replaceUser(id, users[0], {
      allowedTools: JSON.stringify(finalTools),
    });

    const updated = await this.clickhouse.query<any>(
      `SELECT u.*, d.name as departmentName
       FROM users u LEFT JOIN departments d ON u.departmentId = d.id
       WHERE u.id = {id:String} LIMIT 1`,
      { id },
    );

    const user = updated[0];
    return {
      id: user.id,
      name: user.name,
      allowedTools: safeParseTools(user.allowedTools),
    };
  }

  async resetPassword(
    id: string,
    newPassword: string,
    callerIsSuperAdmin: boolean,
  ) {
    if (!newPassword || newPassword.length < 8) {
      throw new BadRequestException(
        "Нууц үг хамгийн багадаа 8 тэмдэгт байх ёстой",
      );
    }
    const complexityRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#^()\-_=+\[\]{}|;:',.<>\/~`])[A-Za-z\d@$!%*?&#^()\-_=+\[\]{}|;:',.<>\/~`]+$/;
    if (!complexityRegex.test(newPassword)) {
      throw new BadRequestException(
        "Нууц үг нь том үсэг, жижиг үсэг, тоо, тусгай тэмдэгт агуулсан байх ёстой",
      );
    }
    const users = await this.clickhouse.query<any>(
      "SELECT * FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );
    if (users.length === 0) throw new NotFoundException("Хэрэглэгч олдсонгүй");
    this.assertCanManageTarget(users[0], callerIsSuperAdmin);
    const hashed = await bcrypt.hash(newPassword, 13);
    // Admin resetting the password is a natural "fix it" moment — clear the
    // persistent lockout too so the user isn't stuck after getting a new password.
    await this.replaceUser(id, users[0], {
      password: hashed,
      isLocked: 0,
      failedLoginCount: 0,
    });
    this.logger.warn(
      `Password reset by admin for user: ${users[0].userId} (${users[0].name})`,
    );
    return {
      message: "Нууц үг амжилттай сэргээлээ",
      userId: users[0].userId,
      name: users[0].name,
    };
  }

  /** Admin: clear the persistent brute-force lockout (5 wrong passwords). */
  async unlockUser(id: string, callerIsSuperAdmin: boolean) {
    const users = await this.clickhouse.query<any>(
      "SELECT * FROM users WHERE id = {id:String} LIMIT 1",
      { id },
    );
    if (users.length === 0) throw new NotFoundException("Хэрэглэгч олдсонгүй");
    this.assertCanManageTarget(users[0], callerIsSuperAdmin);
    await this.replaceUser(id, users[0], {
      isLocked: 0,
      failedLoginCount: 0,
    });
    this.logger.warn(
      `Account unlocked by admin: ${users[0].userId} (${users[0].name})`,
    );
    return {
      message: "Хэрэглэгчийн түгжээ амжилттай гарлаа",
      userId: users[0].userId,
      name: users[0].name,
    };
  }
}
