import {
  IsString,
  IsIn,
  IsOptional,
  IsNotEmpty,
  IsBoolean,
  IsArray,
} from "class-validator";

export class CreatePythonToolDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  /** URL slug — /python-api/run/:apiPath дээр ашиглагдана */
  @IsString()
  @IsNotEmpty()
  apiPath: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  @IsNotEmpty()
  pythonCode: string;

  @IsIn(["clickhouse", "oracle", "clickhouse_oracle"])
  @IsOptional()
  connectionType?: "clickhouse" | "oracle" | "clickhouse_oracle";

  /** JSON string — { host, port, user, password, database, dsn, serviceName, ... } */
  @IsString()
  @IsOptional()
  connectionConfig?: string;

  @IsIn(["excel", "csv"])
  @IsOptional()
  outputFormat?: "excel" | "csv";

  @IsIn(["none", "single", "range"])
  @IsOptional()
  dateMode?: "none" | "single" | "range";

  @IsString()
  @IsOptional()
  color?: string;

  /** JSON string of FilterDef[] */
  @IsString()
  @IsOptional()
  filters?: string;
}

export class UpdatePythonToolDto {
  @IsString()
  @IsOptional()
  name?: string;

  @IsString()
  @IsOptional()
  apiPath?: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  @IsOptional()
  pythonCode?: string;

  @IsIn(["clickhouse", "oracle", "clickhouse_oracle"])
  @IsOptional()
  connectionType?: "clickhouse" | "oracle" | "clickhouse_oracle";

  @IsString()
  @IsOptional()
  connectionConfig?: string;

  @IsIn(["excel", "csv"])
  @IsOptional()
  outputFormat?: "excel" | "csv";

  @IsIn(["none", "single", "range"])
  @IsOptional()
  dateMode?: "none" | "single" | "range";

  @IsString()
  @IsOptional()
  color?: string;

  @IsString()
  @IsOptional()
  filters?: string;
}

export class RunToolDto {
  @IsString()
  @IsNotEmpty()
  toolId: string;

  @IsString()
  @IsOptional()
  startDate?: string;

  @IsString()
  @IsOptional()
  endDate?: string;

  @IsOptional()
  filters?: Record<string, string>;
}

export class ToggleToolDto {
  @IsBoolean()
  isActive!: boolean;
}

export class ReorderToolsDto {
  @IsArray()
  @IsString({ each: true })
  ids!: string[];
}

export class ValidateCodeDto {
  @IsString()
  @IsNotEmpty()
  code!: string;
}

export class PreviewCodeDto {
  @IsString()
  @IsNotEmpty()
  code!: string;

  @IsString()
  @IsOptional()
  connectionType?: string;

  @IsString()
  @IsOptional()
  connectionConfig?: string;

  @IsString()
  @IsOptional()
  startDate?: string;

  @IsString()
  @IsOptional()
  endDate?: string;

  @IsOptional()
  filters?: Record<string, string>;
}

export class GrantPermissionDto {
  @IsString()
  @IsNotEmpty()
  userId!: string;

  @IsString()
  @IsNotEmpty()
  templateId!: string;
}

export class RevokePermissionDto {
  @IsString()
  @IsNotEmpty()
  userId!: string;

  @IsString()
  @IsNotEmpty()
  templateId!: string;
}
